
package kompor.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import kompor.model.Mahasiswa;

public class DBHandler {
    public final Connection conn;
    
    public DBHandler(String driver) {
        this.conn = DBHelper.getConnection(driver);
    }
    public void addMahasiswa(Mahasiswa mhs){
        String insertMhs = "INSERT INTO `kompor`(`nama`, `harga`, `tanggal_beli`,`tipe`,`merk`)"
                + "VALUES (?,?,?,?,?)";
        try {
            PreparedStatement stmtInsert = conn.prepareStatement(insertMhs);
            stmtInsert.setString(1, mhs.getNama());
            stmtInsert.setString(2, mhs.getHarga());
            stmtInsert.setString(3, mhs.getTanggalBeli());
            stmtInsert.setString(4, mhs.getTipe());
            stmtInsert.setString(5, mhs.getMerk());
            stmtInsert.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
